def calcular_media(notas: list) -> float:
    """
    Calcula a média aritmética simples de uma lista de notas.

    Esta função percorre uma lista de valores numéricos e retorna a média.
    Caso a lista esteja vazia, é retornado um ValueError com a mensagem "A lista de notas não pode estar vazia.".

    Args:
        notas (list[int | float]): Uma lista contendo as notas dos alunos entre 0 e 10.
                    Sendo que as notas deverão ser números inteiros ou de ponto flutuante,
                    caso contrário será retornado um erro do tipo TypeError com a mensagem 
                    "As notas devem ser uma lista numérica".


    Returns:
        float: A média aritmética das notas com precisão de 1 casa decimal.

    Raises:
        TypeError: Se a entrada não for uma lista ou se contiver elementos não numéricos.

    Example:
        >>> calcular_media([10, 8, 6])
        8.0
        >>> calcular_media([7.5, 8.0, 10.0])
        8.5
    """

    if len(notas) ==0:
        raise ValueError("A lista de notas não pode estar vazia.")
    
    if not isinstance(notas, list):
        raise TypeError("As notas devem ser uma lista numérica")

    # if not notas:
    #     raise ValueError("A lista de notas não pode estar vazia.")
    
    # for nota in notas:
    #     if not isinstance(nota, (int, float)):
    #         raise TypeError("As notas devem ser uma lista numérica")
    
    for nota in notas:
        if nota > 10 or nota < 0:
            raise ValueError("As notas devem ser entre 0 e 10.")
    
    soma = sum(notas)
    media = soma / len(notas)
    return round(float(media), 1)
